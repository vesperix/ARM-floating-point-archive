#include "atlas_misc.h"

int ATL_IAMAX(const int N, const TYPE *X, const int incX)
{
   int ATL_UIAMAX(const int N, const TYPE *X, const int incX);
   return(ATL_UIAMAX(N, X, incX));
}
