#include <stdio.h>
void c_routine_(double *d)  { *d = 1.0; }
void c_routine(double *d)   { *d = 2.0; }
void C_ROUTINE(double *d)  { *d = 3.0; }
void c_routine__(double *d) { *d = 4.0; }
